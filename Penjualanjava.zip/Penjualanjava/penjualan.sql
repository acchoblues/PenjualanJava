-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 01, 2013 at 01:32 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `djual`
--

CREATE TABLE IF NOT EXISTS `djual` (
  `no_jual` varchar(10) NOT NULL default '',
  `kdbrg` char(5) NOT NULL default '',
  `harga_jual` float default NULL,
  `jml_jual` int(4) default NULL,
  PRIMARY KEY  (`no_jual`,`kdbrg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `djual`
--

INSERT INTO `djual` (`no_jual`, `kdbrg`, `harga_jual`, `jml_jual`) VALUES
('12120002', 'b-002', 20000, 2),
('12120002', 'b-003', 25000, 2),
('12120001', 'b-001', 10000, 2),
('12120001', 'b-003', 25000, 2),
('12120003', 'b-003', 25000, 2),
('12120003', 'b-001', 10000, 8);

-- --------------------------------------------------------

--
-- Table structure for table `jual`
--

CREATE TABLE IF NOT EXISTS `jual` (
  `no_jual` varchar(10) NOT NULL default '',
  `kdkon` char(6) default NULL,
  `nmkon` varchar(30) character set latin1 collate latin1_general_ci default NULL,
  `tgl_jual` date default NULL,
  `total` int(10) default NULL,
  `bayar` int(10) default NULL,
  `kembalian` int(10) default NULL,
  PRIMARY KEY  (`no_jual`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jual`
--

INSERT INTO `jual` (`no_jual`, `kdkon`, `nmkon`, `tgl_jual`, `total`, `bayar`, `kembalian`) VALUES
('12120001', '000004', 'hakko bio richard', '2012-12-31', 70000, 100000, 30000),
('12120002', '000004', 'hakko bio richard', '2012-12-31', 90000, 100000, 10000),
('12120003', '000002', 'aji', '2013-01-01', 130000, 150000, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `tblbrg`
--

CREATE TABLE IF NOT EXISTS `tblbrg` (
  `kdbrg` varchar(5) NOT NULL default '',
  `nmbrg` varchar(25) default NULL,
  `satuan` varchar(10) default NULL,
  `harga` int(11) default NULL,
  `stok` int(11) default NULL,
  `stokmin` int(11) default NULL,
  PRIMARY KEY  (`kdbrg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrg`
--

INSERT INTO `tblbrg` (`kdbrg`, `nmbrg`, `satuan`, `harga`, `stok`, `stokmin`) VALUES
('b-003', 'kaos', 'Lusin', 25000, 20, 2),
('b-001', 'hecter', 'Buah', 10000, 20, 10),
('b-002', 'penghapus', 'Lusin', 20000, 20, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblkonsumen`
--

CREATE TABLE IF NOT EXISTS `tblkonsumen` (
  `kdkon` varchar(6) NOT NULL default '',
  `nmkon` varchar(35) default NULL,
  `notelp` varchar(15) default NULL,
  `alamat` text,
  PRIMARY KEY  (`kdkon`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblkonsumen`
--

INSERT INTO `tblkonsumen` (`kdkon`, `nmkon`, `notelp`, `alamat`) VALUES
('000004', 'hakko bio richard', '085694984803', 'kp.sempu no.118 rt.03/03 desa pasir gombong'),
('000001', 'anton sugianto', '085609875467', 'cikarang'),
('000002', 'aji', '085676767676', 'njerman'),
('000005', 'hendra', '08567654345', 'cikarang');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(4) NOT NULL default '0',
  `user_id` varchar(10) default NULL,
  `name` varchar(30) default NULL,
  `password` varchar(254) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_id`, `name`, `password`) VALUES
(1234, 'hakko', 'hakko bio richard', 'hakko');
